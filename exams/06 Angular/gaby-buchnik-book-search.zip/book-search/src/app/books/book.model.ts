export interface book{
    title : string;
    authors : string;
    previewLink : string;
}